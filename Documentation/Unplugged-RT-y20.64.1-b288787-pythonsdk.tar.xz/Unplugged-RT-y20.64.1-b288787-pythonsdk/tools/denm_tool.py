#!/usr/bin/env python3
#
# Copyright (C) Commsignia Ltd. - All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
# Date 2022-2024

"""Tool for triggering DENM via remote API."""

import time
from argparse import ArgumentParser, Namespace, RawTextHelpFormatter

from pycmssdk import (
    DenmAction,
    DenmActionId,
    DenmAutoFlags,
    DenmCreate,
    DenmManagementData,
    DenmTermination,
    GnTrafficClass,
    api,
    create_cms_api,
)
from pycmssdk.asn1 import Asn1Type, asn1_encode

DENM_TEMPLATE = {
    "management": {
        "actionID": {
            "originatingStationID": 0,
            "sequenceNumber": 0,
        },
        "detectionTime": 0,
        "referenceTime": 0,
        "eventPosition": {
            "latitude": 0,
            "longitude": 0,
            "positionConfidenceEllipse": {
                "semiMajorConfidence": 0,
                "semiMinorConfidence": 0,
                "semiMajorOrientation": 0,
            },
            "altitude": {"altitudeValue": 0, "altitudeConfidence": "alt-000-01"},
        },
        "relevanceDistance": "lessThan1000m",
        "stationType": 0,
    },
    "situation": {
        "eventType": {
            "causeCode": 0,
            "subCauseCode": 0,
        },
        "informationQuality": 0,
    },
}


def parse_args():
    """Parse command line arguments."""

    parser = ArgumentParser(
        description="Commsignia DENM trigger tool. "
        "Triggers and terminates DENM sending via the remote API.\n"
        "\n"
        "Example for triggering an EEBL DENM: \n"
        "\tdenm_tool.py --causeCode 99 --subCauseCode 1 --repetitionInterval 100 --repetitionDuration 2000"
        "# Trigger DENM sending for 2 seconds every 100 ms\n",
        formatter_class=RawTextHelpFormatter,
    )
    parser.add_argument("--causeCode", type=int, required=True, help="Cause code")
    parser.add_argument("--subCauseCode", type=int, default=0, help="Sub cause code [default: 0]")
    parser.add_argument(
        "--ip", type=str, default="127.0.0.1", help="External Api Server (EAS) IP address [default: 127.0.0.1]"
    )
    parser.add_argument("--port", type=int, default=7942, help="External Api Server (EAS) port [default: 7942]")
    parser.add_argument(
        "--repetitionDuration", type=int, default=2000, help="Repeat DENM until N ms elapses [default: 2000]"
    )
    parser.add_argument("--repetitionInterval", type=int, default=1000, help="Repeat DENM every N ms [default: 1000]")
    parser.add_argument(
        "--validityDuration", type=int, default=2, help="DENM validity duration in seconds [default: 2]"
    )
    parser.add_argument(
        "--keepValidityDuration", action="store_true", help="Keep previous validity duration [default: False]"
    )
    parser.add_argument("--updateDuration", type=int, default=0, help="Update DENM until N ms elapses [default: 0]")
    parser.add_argument("--updateInterval", type=int, default=0, help="Update DENM every N ms [default: 0]")
    parser.add_argument("--informationQuality", type=int, default=1, help="Information quality [default: 1]")
    parser.add_argument("--gnTcid", type=int, default=2, help="GN traffic class ID [default: 2]")
    parser.add_argument(
        "--action",
        type=DenmAction.from_string,
        choices=list(DenmAction),
        default=DenmAction.DENM_ACTION_CREATE_OR_UPDATE,
        help="DENM action [default: DENM_ACTION_CREATE_OR_UPDATE]",
    )
    parser.add_argument("--stationId", type=int, help="Station ID [default: automatically set)]")
    parser.add_argument("--sequenceNumber", type=int, help="Sequence number [default: automatically set]")
    return parser.parse_args()


def ns_to_ms(ns: int) -> float:
    """Convert nanoseconds to milliseconds."""
    return ns * 1e-6


def ms_to_sec(ms: int) -> float:
    """Convert milliseconds to seconds."""

    return ms * 1e-3


def sec_to_ms(sec: float) -> int:
    """Convert seconds to milliseconds."""
    return sec * 1e3


def create_encoded_denm(args: Namespace, action_id: DenmActionId):
    """Create and encode DENM message."""

    denm = DENM_TEMPLATE
    denm["management"]["validityDuration"] = args.validityDuration
    if action_id:
        denm["management"]["actionID"]["originatingStationID"] = action_id.station_id
        denm["management"]["actionID"]["sequenceNumber"] = action_id.sequence_number
    denm["situation"]["eventType"]["causeCode"] = args.causeCode
    denm["situation"]["eventType"]["subCauseCode"] = args.subCauseCode
    denm["situation"]["informationQuality"] = args.informationQuality

    return asn1_encode(denm, Asn1Type.EU_DECENTRALIZED_ENVIRONMENT_NOTIFICATION)


def terminate_after_repetition_duration(
    cms_api: api,
    action_id: DenmActionId,
    denm_timestamp_ms: int,
    repetition_duration_ms: int,
    validity_duration_ms: int,
):
    """
    Terminate DENM after repetition duration expires. If the DENM is no longer valid
    at the time repetition duration expires, skip DENM termination.
    """
    if validity_duration_ms > repetition_duration_ms:
        current_time_ms = ns_to_ms(time.time_ns())
        if current_time_ms < denm_timestamp_ms + repetition_duration_ms:
            sleep_time_ms = denm_timestamp_ms + repetition_duration_ms - current_time_ms
            time.sleep(ms_to_sec(sleep_time_ms))
            cms_api.denm_terminate(DenmTermination(action_id=action_id))


def send_denm_trigger(args: Namespace, cms_api: api, encoded_denm: bytes):
    """Send DENM trigger via the remote API."""
    response = cms_api.denm_create_or_update(
        data=DenmCreate(
            auto_flags=DenmAutoFlags(
                auto_calc_action_id=args.stationId is None and args.sequenceNumber is None,
                auto_set_detection_time=True,
                auto_set_event_position=True,
                auto_set_event_trace=True,
                auto_set_destination_area=True,
                keep_validity_duration=args.keepValidityDuration,
            ),
            management=DenmManagementData(
                gn_hop_limit=2,
                repetition_duration=args.repetitionDuration,
                repetition_interval=args.repetitionInterval,
                gn_traffic_class=GnTrafficClass(tcid=args.gnTcid),
            ),
            action=args.action,
        ),
        buffer=encoded_denm,
    )
    action_id = response.data
    assert action_id is not None

    return action_id


def main():
    """
    Entry point of DENM triggering tool.

    :param args:
        Command line arguments.
    """

    args = parse_args()
    if args.stationId is not None and args.sequenceNumber is not None:
        action_id = DenmActionId
        action_id.station_id = args.stationId
        action_id.sequence_number = args.sequenceNumber
    else:
        action_id = None

    with create_cms_api(host=args.ip, port=args.port) as cms_api:
        update_time_left_ms = args.updateDuration
        while True:
            encoded_denm = create_encoded_denm(args, action_id)
            action_id = send_denm_trigger(args, cms_api, encoded_denm)
            denm_timestamp_ms = ns_to_ms(time.time_ns())
            sleep_time_ms = min(update_time_left_ms, args.updateInterval)
            time.sleep(ms_to_sec(sleep_time_ms))
            update_time_left_ms -= sleep_time_ms
            if update_time_left_ms == 0:
                break

        terminate_after_repetition_duration(
            cms_api, action_id, denm_timestamp_ms, args.repetitionDuration, sec_to_ms(args.validityDuration)
        )


if __name__ == "__main__":
    main()
